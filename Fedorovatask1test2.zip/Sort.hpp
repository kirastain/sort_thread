#pragma once

#include <iostream>
#include <thread>
#include <exception>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <sstream>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <ctime>
#include <bitset>

#define BUFF_SIZE 419430400

using namespace std;